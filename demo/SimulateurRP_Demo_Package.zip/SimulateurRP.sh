#!/bin/bash

java -Dsun.java2d.opengl=true -jar sources/SimulateurRP_Project.jar
